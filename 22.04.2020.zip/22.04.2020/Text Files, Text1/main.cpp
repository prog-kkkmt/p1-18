#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main () {
int a;
int i;
string stars;
cin >> a;
cin >> stars;
ofstream file;
file.open("file.txt");
for (i = 0; i < a; i++) {
    file << stars;
}
return 0;
}
