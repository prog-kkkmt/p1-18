#Array11. Дан массив A размера N и целое число K (1 ≤ K ≤ N).
#Вывести элементы массива с порядковыми номерами, кратными K: AK, A2·K, A3·K, … .
#Условный оператор не использовать.
a = []
n = int(input())
k = int(input())
i = 0
for i in  range (n):
    x = int(input())
    a.append(x)
for i in  range (n):
    if (i % k == 0):
        print(a[i])
    