#Minmax11. Дано целое число N и набор из N целых чисел. 
#Найти номер последнего экстремального (т. е. минимального или максимального) элемента из данного набора.

n = int(input())
lst = []
for i in range (n):
    x = int(input())
    lst.append(x)
i = 1
b = lst[0]
k = lst[0]
c = int(0)
x = int(0)
for i in range (n):
    if (b > lst[i]):
        c = i
    elif (k < lst[i]):
        x = i
    b = lst[i]
    k = lst[i]
if (c > x):
    print(c)
else: 
    print(x)

    
