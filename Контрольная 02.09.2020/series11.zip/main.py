# Series11. Даны целые числа K, N и набор из N целых чисел. 
# Если в наборе имеются числа, меньшие K, то вывести True; 
# в противном случае вывести False.
k = int(input())
n = int(input())
i = int(0)
lst = []
for i in range (n):
    x = int(input())
    lst.append(x)
b = 0
i = 0
for i in range (n):
    if (k > lst[i]):
        b = 1
if (b == 1):
    print("True")
else:
    print("False")

    
