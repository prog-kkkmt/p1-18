#String11. Дана непустая строка S.
#Вывести строку, содержащую символы строки S, между которыми вставлено по одному пробелу.
x = 0
lst = input()
x = len(lst)
print(x)
i = 0
j = 0
f = " "
l = []
i = 1
j = 0
for i in range (x * 2):
    if (i % 2 == 0):
        l.append(lst[j])
        j += 1
    else:
        l.append(f)
print(l)