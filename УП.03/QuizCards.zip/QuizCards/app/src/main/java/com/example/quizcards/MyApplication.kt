package com.example.quizcards

import android.app.Application
import android.content.Context

class MyApplication : Application() {
    companion object {
        private lateinit var currentInstance: MyApplication

        val context: Context
            get() = currentInstance.applicationContext
    }

    override fun onCreate() {
        super.onCreate()
        currentInstance = this
    }
}