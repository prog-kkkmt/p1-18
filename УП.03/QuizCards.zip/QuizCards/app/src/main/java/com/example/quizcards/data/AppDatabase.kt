package com.example.quizcards.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Реализация класса БД для Room-фреймворка.
 */
@Database(entities = [Card::class, Deck::class], version = 1)
abstract class AppDatabase : RoomDatabase() {

    abstract fun cardDao() : CardDao
    abstract fun deckDao() : DeckDao

    companion object {
        private var instance: AppDatabase? = null
        private const val DATABASE_NAME = "QuizDatabase"

        fun getInstance(context: Context): AppDatabase {
            return instance ?: buildDatabase(context).also { instance = it }
        }

        private fun buildDatabase(context: Context): AppDatabase {
            return Room.databaseBuilder(context, AppDatabase::class.java, DATABASE_NAME)
                .addCallback(DB_CALLBACK)
                .build()
        }

        /**
         * SQL-триггер для удаления карточек при удалении колоды.
         */
        private val DB_CALLBACK = object : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                db.execSQL(
                    """
                        CREATE TRIGGER IF NOT EXISTS deck_deleted AFTER DELETE ON deck
                        BEGIN
                            DELETE FROM card
                            WHERE old.id = deck_id;
                        END;
                    """.trimIndent()
                )
            }
        }
    }

}