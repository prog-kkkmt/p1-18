package com.example.quizcards.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "card")
data class Card(
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    var front: String,
    var back: String,
    val deck_id: Int
)
