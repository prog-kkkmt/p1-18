package com.example.quizcards.data

import androidx.room.*

/**
 * Объект получения данных (Data access object) для карт.
 */
@Dao
interface CardDao {

    @Query("SELECT * FROM card WHERE deck_id = :deckId")
    fun getCards(deckId: Int): List<Card>

    @Insert
    fun insertCard(card: Card)

    @Update
    fun updateCard(card: Card)

    @Delete
    fun deleteCard(card: Card)

}