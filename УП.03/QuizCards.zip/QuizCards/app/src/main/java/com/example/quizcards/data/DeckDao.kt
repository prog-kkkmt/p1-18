package com.example.quizcards.data

import androidx.room.*

/**
 * Объект получения данных (Data access object) для колод.
 */
@Dao
interface DeckDao {

    @Query("SELECT * FROM deck WHERE id = :deckId")
    fun getDeck(deckId: Int): Deck

    @Query("SELECT * FROM deck")
    fun getDecks(): List<Deck>

    @Query("SELECT 1 FROM card WHERE deck_id = :deckId LIMIT 1")
    fun isDeckEmpty(deckId: Int): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertDeck(deck: Deck)

    @Update(onConflict = OnConflictStrategy.IGNORE)
    fun updateDeck(deck: Deck)

    @Delete
    fun deleteDeck(deck: Deck)

}