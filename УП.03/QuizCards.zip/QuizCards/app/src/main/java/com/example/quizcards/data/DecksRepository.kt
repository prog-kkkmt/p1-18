package com.example.quizcards.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Репозиторий для получения данных из БД.
 */
class DecksRepository private constructor() : Repository {

    companion object {
        private var instance: DecksRepository? = null

        fun getInstance(): DecksRepository {
            return instance ?: DecksRepository().also { instance = it }
        }
    }

    override suspend fun addDeck(context: Context, deck: Deck) {
        withContext(Dispatchers.IO) {
            AppDatabase.getInstance(context).deckDao().insertDeck(deck)
        }
    }

    override suspend fun updateDeck(context: Context, deck: Deck) {
        withContext(Dispatchers.IO) {
            AppDatabase.getInstance(context).deckDao().updateDeck(deck)
        }
    }

    override suspend fun deleteDeck(context: Context, deck: Deck) {
        withContext(Dispatchers.IO) {
            AppDatabase.getInstance(context).deckDao().deleteDeck(deck)
        }
    }

    override suspend fun isDeckEmpty(context: Context, deck: Deck): Boolean {
        val isDeckEmpty: Boolean
        val result: Int

        withContext(Dispatchers.IO) {
            result = AppDatabase.getInstance(context).deckDao().isDeckEmpty(deck.id)
        }

        return result != 1
    }

    override suspend fun getDeck(context: Context, deckId: Int): Deck {
        val deck: Deck

        withContext(Dispatchers.IO) {
            deck = AppDatabase.getInstance(context).deckDao().getDeck(deckId)
        }

        return deck
    }

    override suspend fun getDecks(context: Context): List<Deck> {
        val decks = ArrayList<Deck>()

        withContext(Dispatchers.IO) {
            decks.addAll(AppDatabase.getInstance(context).deckDao().getDecks())
        }

        return decks
    }

    override suspend fun addCard(context: Context, card: Card) {
        withContext(Dispatchers.IO) {
            AppDatabase.getInstance(context).cardDao().insertCard(card)
        }
    }

    override suspend fun updateCard(context: Context, card: Card) {
        withContext(Dispatchers.IO) {
            AppDatabase.getInstance(context).cardDao().updateCard(card)
        }
    }

    override suspend fun deleteCard(context: Context, card: Card) {
        withContext(Dispatchers.IO) {
            AppDatabase.getInstance(context).cardDao().deleteCard(card)
        }
    }

    override suspend fun getCards(context: Context, deckId: Int): List<Card> {
        val cards = ArrayList<Card>()

        withContext(Dispatchers.IO) {
            cards.addAll(AppDatabase.getInstance(context).cardDao().getCards(deckId))
        }

        return cards
    }

}