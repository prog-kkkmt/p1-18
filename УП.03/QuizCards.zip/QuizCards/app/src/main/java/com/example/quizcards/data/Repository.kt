package com.example.quizcards.data

import android.content.Context

/**
 * Интерфейс для классов, которые используются для получения данных.
 */
interface Repository {
    suspend fun addDeck(context: Context, deck: Deck)
    suspend fun updateDeck(context: Context, deck: Deck)
    suspend fun deleteDeck(context: Context, deck: Deck)
    suspend fun isDeckEmpty(context: Context, deck: Deck): Boolean
    suspend fun getDeck(context: Context, deckId: Int): Deck
    suspend fun getDecks(context: Context): List<Deck>
    suspend fun addCard(context: Context, card: Card)
    suspend fun updateCard(context: Context, card: Card)
    suspend fun deleteCard(context: Context, card: Card)
    suspend fun getCards(context: Context, deckId: Int): List<Card>
}