package com.example.quizcards.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.quizcards.R
import com.example.quizcards.data.Card

/**
 * Адаптер для списка с картами. Определяет вид и поведение катрочек в списке.
 */
class CardListAdapter(private val cards: ArrayList<Card>):
    RecyclerView.Adapter<CardListAdapter.ViewHolder>() {

    class ViewHolder(val cardView: LinearLayout) : RecyclerView.ViewHolder(cardView)

    interface Listener {
        fun onCardClicked(position: Int)
    }

    var listener: Listener? = null

    override fun getItemCount() = cards.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val cardView = LayoutInflater.from(parent.context)
            .inflate(R.layout.card_list_item, parent, false) as LinearLayout
        return ViewHolder(cardView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val card = cards[position]

        val frontView = holder.cardView.findViewById<TextView>(R.id.card_front)
        val backView = holder.cardView.findViewById<TextView>(R.id.card_back)

        frontView.text = card.front
        backView.text = card.back

        holder.cardView.setOnClickListener { listener?.onCardClicked(position) }
    }

}