package com.example.quizcards.ui.adapters

import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.*
import androidx.core.animation.doOnEnd
import androidx.core.view.doOnLayout
import androidx.core.view.doOnNextLayout
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.example.quizcards.R
import com.example.quizcards.data.Deck

/**
 * Адаптер для списка с колодами. Определяет вид и поведение колод в списке.
 */
class DeckListAdapter(private val decks: ArrayList<Deck>) :
    RecyclerView.Adapter<DeckListAdapter.ViewHolder>() {

    class ViewHolder(val deckView: RelativeLayout) : RecyclerView.ViewHolder(deckView) {
        val expandView = deckView.findViewById<LinearLayout>(R.id.sub_item)
    }

    interface Listener {
        fun onEditButtonClicked(position: Int)
        fun onPlayButtonClicked(view: View, position: Int)
    }

    var listener: Listener? = null

    // hardcoded heights because all items have same height
    private var originalHeight = 140
    private var expandedHeight = 270

    private var expandedDeck: Deck? = null

    private val listItemExpandDuration = 220L
    private lateinit var recyclerView: RecyclerView

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        this.recyclerView = recyclerView
    }

    override fun getItemCount(): Int = decks.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val deckView = LayoutInflater.from(parent.context)
            .inflate(R.layout.deck_list_item, parent,false) as RelativeLayout
        return ViewHolder(deckView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val deck = decks[position]

        bindViews(holder, position)
        expandItem(holder, deck == expandedDeck, false)

        holder.deckView.setOnClickListener {
            if (expandedDeck == null) {
                expandItem(holder, expand = true, animate = true)
                expandedDeck = deck
            } else if (expandedDeck == deck) {
                expandItem(holder, expand = false, animate = true)
                expandedDeck = null
            } else {
                val expandedDeckPosition = decks.indexOf(expandedDeck)
                val oldViewHolder =
                    recyclerView.findViewHolderForAdapterPosition(expandedDeckPosition) as ViewHolder
                if (oldViewHolder != null) expandItem(oldViewHolder, expand = false, animate = true)

                expandItem(holder, expand = true, animate = true)
                expandedDeck = deck
            }
        }
    }

    private fun bindViews(holder: ViewHolder, position: Int) {
        with(holder.deckView) {
            val deckNameView = findViewById<TextView>(R.id.deck_name)
            val editButton = findViewById<ImageButton>(R.id.edit_button)
            val playButton = findViewById<Button>(R.id.play_button)

            deckNameView.text = decks[position].title
            editButton.setOnClickListener { listener?.onEditButtonClicked(position) }
            playButton.setOnClickListener { listener?.onPlayButtonClicked(this, position) }
            holder.deckView.setOnLongClickListener {
                Toast.makeText(context, "Long press", Toast.LENGTH_SHORT).show()
                true
            }
        }
    }

    private fun expandItem(holder: ViewHolder, expand: Boolean, animate: Boolean) {
        if (animate) {
            Log.d("qwe", "expandItemWithAnimate")
            val animator = getValueAnimator(
                expand, listItemExpandDuration, AccelerateDecelerateInterpolator()
            ) { progress -> setExpandProgress(holder, progress) }

            if (expand) animator.doOnEnd { holder.expandView.isVisible = true }

            animator.start()
        } else {
            holder.expandView.isVisible = expand
            setExpandProgress(holder, if (expand) 1f else 0f)
        }
    }

    private fun setExpandProgress(holder: ViewHolder, progress: Float) {
        if (expandedHeight > 0 && originalHeight > 0) {
            holder.deckView.layoutParams.height =
                (originalHeight + (expandedHeight - originalHeight) * progress).toInt()
        }

        holder.deckView.requestLayout()
    }

    inline fun getValueAnimator(forward: Boolean = true, duration: Long, interpolator: TimeInterpolator,
                                crossinline updateListener: (progress: Float) -> Unit
    ): ValueAnimator {
        val a =
            if (forward) ValueAnimator.ofFloat(0f, 1f)
            else ValueAnimator.ofFloat(1f, 0f)
        a.addUpdateListener { updateListener(it.animatedValue as Float) }
        a.duration = duration
        a.interpolator = interpolator
        return a
    }

}