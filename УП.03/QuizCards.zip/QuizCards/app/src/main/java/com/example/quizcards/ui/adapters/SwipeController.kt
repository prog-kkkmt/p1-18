package com.example.quizcards.ui.adapters

import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.RemoteInput
import android.graphics.*
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.core.animation.doOnEnd
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.ItemTouchHelper.*
import androidx.recyclerview.widget.RecyclerView
import com.example.quizcards.MyApplication
import com.example.quizcards.R

/**
 * Возможные состояния кнопки удаления.
 */
enum class ButtonState {
    GONE,
    VISIBLE
}

/**
 * Класс, который настраивает swipe для списка с картами.
 */
class SwipeController(val buttonAction: SwipeControllerAction) : ItemTouchHelper.Callback() {
    private var swipeBack = false
    private var buttonState = ButtonState.GONE
    private var buttonFieldWidth = 160
    private var currentItemViewHolder: RecyclerView.ViewHolder? = null
    private var buttonInstance: RectF? = null
    private var recycler: RecyclerView? = null

    override fun getMovementFlags(
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder
    ): Int {
        return makeMovementFlags(0, LEFT or RIGHT)
    }

    override fun onMove(
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder,
        target: RecyclerView.ViewHolder
    ): Boolean {
        return false
    }

    override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) { }

    override fun convertToAbsoluteDirection(flags: Int, layoutDirection: Int): Int {
        if (swipeBack) {
            swipeBack = buttonState != ButtonState.GONE
            return 0
        }

        return super.convertToAbsoluteDirection(flags, layoutDirection)
    }

    override fun onChildDraw(
        c: Canvas,
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder,
        dX: Float,
        dY: Float,
        actionState: Int,
        isCurrentlyActive: Boolean
    ) {
        if (recycler == null) recycler = recyclerView

        if (actionState == ACTION_STATE_SWIPE) {
            if (buttonState == ButtonState.VISIBLE) {
                val newDX = -buttonFieldWidth.toFloat()
                super.onChildDraw(
                    c, recyclerView, viewHolder, newDX, dY, actionState, isCurrentlyActive)
            } else {
                setTouchListener(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
            }
        }

        if(buttonState == ButtonState.GONE) {
            var newDX = maxOf(dX, -buttonFieldWidth.toFloat())
            newDX = newDX.coerceAtMost(0F)
            super.onChildDraw(c, recyclerView, viewHolder, newDX, dY, actionState, isCurrentlyActive)
        }

        currentItemViewHolder = viewHolder
    }

    /**
     * Устанавливает обработчик нажатия при swipe.
     * Если пользователь передвинул элемент списка на достаточное расстояния для кнопки удаления,
     * данная функция вызывает setTouchDownListener, который определяет новый обработчик нажатия.
     * @see setTouchDownListener
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun setTouchListener(
        c: Canvas,
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder,
        dX: Float,
        dY: Float,
        actionState: Int,
        isCurrentlyActive: Boolean
    ) {
        recyclerView.setOnTouchListener { v, event ->
            swipeBack = event.action == MotionEvent.ACTION_CANCEL ||
                    event.action == MotionEvent.ACTION_UP
            if (swipeBack) {
                if (dX < -buttonFieldWidth) buttonState = ButtonState.VISIBLE

                if (buttonState != ButtonState.GONE) {
                    setTouchDownListener(
                        c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
                    setItemsClickable(recyclerView, false)
                }
            }

            false
        }
    }

    /**
     * Устанавливает обработчик события после того, как пользователь отпустил элемент и кнопка стала видомой.
     * Если пользователь начал нажатие на кнопке, то устанавливается следующий обработчик события (вызывается setTouchUpListener).
     * Если пользователь начал нажатие на на текущем элементе, то текущий элемент закрывается.
     * @see setTouchUpListener
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun setTouchDownListener(
        c: Canvas,
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder,
        dX: Float,
        dY: Float,
        actionState: Int,
        isCurrentlyActive: Boolean
    ) {
        recyclerView.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                // Пользователь нажал на кнопку
                if (buttonInstance != null && buttonInstance!!.contains(event.x, event.y)) {
                    setTouchUpListener(
                        c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive
                    )
                } else {
                    var isCurrentItemSwiping = false
                    if (buttonInstance != null) {
                        isCurrentItemSwiping =
                            buttonInstance!!.bottom >= event.y && buttonInstance!!.top <= event.y
                    }
                    if (buttonInstance == null || !isCurrentItemSwiping) {
                        closeCurrentItem(
                            c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive
                        )

                        recyclerView.setOnTouchListener { v, event -> false }
                        setItemsClickable(recyclerView, true)
                        swipeBack = false
                        buttonState = ButtonState.GONE
                        currentItemViewHolder = null
                    } else {
                        recyclerView.setOnTouchListener { v, event -> false }
                        setItemsClickable(recyclerView, true)
                        swipeBack = false
                        buttonState = ButtonState.GONE
                        currentItemViewHolder = null
                    }
                }
            }

            false
        }
    }

    /**
     * Устанавливает обработчик нажатия после того, как пользоваетель начал нажатие на кнопке удаления.
     * Если пользователь закончкил нажатие над кнопкой, то срабатывает клик на кнопку.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun setTouchUpListener(
        c: Canvas,
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder,
        dX: Float,
        dY: Float,
        actionState: Int,
        isCurrentlyActive: Boolean
    ) {
        recyclerView.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
                var reverse = false
                if (buttonInstance != null && buttonInstance!!.contains(event.x, event.y)) {
                    if (buttonState == ButtonState.VISIBLE) {
                        buttonAction.onButtonClicked(viewHolder.adapterPosition)
                        reverse = true
                    }
                }

                closeCurrentItem(
                    c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive, reverse
                )

                recyclerView.setOnTouchListener { v, event -> false }
                setItemsClickable(recyclerView, true)
                swipeBack = false
                buttonState = ButtonState.GONE
                currentItemViewHolder = null
            }

            false
        }
    }

    /**
     * Сдвигает текущий открытый элемент на исходную позицию (с анимацией)
     */
    private fun closeCurrentItem(
        c: Canvas,
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder,
        dX: Float,
        dY: Float,
        actionState: Int,
        isCurrentlyActive: Boolean,
        reverse: Boolean = false
    ) {
        val animator = getValueAnimator(
            true, 300L, AccelerateDecelerateInterpolator()
        ) { progress ->
            val newDX = -buttonFieldWidth + (buttonFieldWidth * progress * if (reverse) -1 else 1)
            super.onChildDraw(
                c, recyclerView, viewHolder, newDX, dY, actionState, isCurrentlyActive
            )
        }

        // Сдвигаем элемент в начало, чтобы новые элементы отображались корректно.
        animator.doOnEnd {
            super.onChildDraw(
                c, recyclerView, viewHolder, 0F, dY, actionState, isCurrentlyActive
            )
        }

        animator.start()
    }

    /**
     * Устанавливает свойство isClickable всех элементов данного RecyclerView значением аргумента ф-ции isClickable.
     */
    private fun setItemsClickable(recyclerView: RecyclerView, isClickable: Boolean) {
        for (i in 0..recyclerView.childCount) {
            recyclerView.getChildAt(i)?.isClickable = isClickable
        }
    }

    /**
     * Рисует кнопку удаления рядом с данным viewHolder. Использует canvas для рисования.
     */
    @SuppressLint("UseCompatLoadingForDrawables")
    private fun drawButton(c: Canvas, viewHolder: RecyclerView.ViewHolder) {
        val paddingHorizontal = 40
        val paddingVertical = 8
        val corners = 999f

        val itemView = viewHolder.itemView
        val buttonWidth = itemView.height - paddingVertical * 2
        buttonFieldWidth = buttonWidth + paddingHorizontal * 2

        val p = Paint()

        val deleteButton = RectF(
            itemView.right.toFloat() - buttonWidth - paddingHorizontal,
            itemView.bottom.toFloat() - buttonWidth - paddingVertical,
            itemView.right.toFloat() - paddingHorizontal,
            itemView.bottom.toFloat() - paddingVertical
        )

        p.color = Color.RED
        c.drawRoundRect(deleteButton, corners, corners, p)
        val theme = MyApplication.context.theme
        val drawable =
            MyApplication.context.resources.getDrawable(R.drawable.outline_delete_24, theme)
        val drawablePadding = 10
        drawable.setBounds(
            itemView.right - buttonWidth - paddingHorizontal + drawablePadding,
            itemView.bottom - buttonWidth - paddingVertical + drawablePadding,
            itemView.right - paddingHorizontal - drawablePadding,
            itemView.bottom - paddingVertical - drawablePadding
        )
        drawable.draw(c)

        buttonInstance = if (buttonState == ButtonState.VISIBLE) deleteButton else null
    }

    /**
     * Срабатывает при перерисовке recyclerView.
     * Рисует кнопку и отключает клик на элементы списка, если кнопка видна.
     * (необходимо для корректной работы при добавлении новых эелементов)
     */
    fun onDraw(c: Canvas) {
        if (currentItemViewHolder != null) {
            drawButton(c, currentItemViewHolder!!)
        }
        if (recycler != null && buttonState == ButtonState.VISIBLE) {
            setItemsClickable(recycler!!, false) // disable new item on add item to recycler
        }
    }

    /**
     * Возвращает настроенный valueAnimator для анимации
     * @param forward Если true, то значение меняется от 0 до 1, иначе от 1 до 0
     * @param duration Длительность анимации
     * @param interpolator Устанавливает интерполяцию для анимации
     * @param updateListener Вызвается при изменении прогресса значения
     */
    private inline fun getValueAnimator(forward: Boolean = true, duration: Long, interpolator: TimeInterpolator,
                                        crossinline updateListener: (progress: Float) -> Unit
    ): ValueAnimator {
        val a =
            if (forward) ValueAnimator.ofFloat(0f, 1f)
            else ValueAnimator.ofFloat(1f, 0f)
        a.addUpdateListener { updateListener(it.animatedValue as Float) }
        a.duration = duration
        a.interpolator = interpolator
        return a
    }
}