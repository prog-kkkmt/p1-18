package com.example.quizcards.ui.adapters

/**
 * Интерфейс для получения события из класса SwipeController
 * @see SwipeController
 */
interface SwipeControllerAction {
    fun onButtonClicked(position: Int)
}