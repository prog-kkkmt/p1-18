package com.example.quizcards.ui.fragments

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Canvas
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import androidx.fragment.app.DialogFragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.quizcards.R
import com.example.quizcards.data.Card
import com.example.quizcards.data.Deck
import com.example.quizcards.data.DecksRepository
import com.example.quizcards.data.Repository
import com.example.quizcards.ui.adapters.CardListAdapter
import com.example.quizcards.ui.adapters.SwipeController
import com.example.quizcards.ui.adapters.SwipeControllerAction
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

/**
 * Класс экрана редактирования колоды.
 */
class DeckDetailedFragment : Fragment(),
    CardListAdapter.Listener,
    CardDialogFragment.CardDialogListener,
    ExitConfirmationDialogFragment.ExitConfirmationDialogListener,
    DeleteConfirmationDialogFragment.DeleteConfirmationDialogListener {

    private val repository: Repository = DecksRepository.getInstance()
    private val cards = ArrayList<Card>()
    private var deckId = 1
    private var initialDeckTitle: String = ""
    private lateinit var layout: View
    private lateinit var list: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        layout = inflater.inflate(R.layout.fragment_deck_detailed, container, false)

        list = layout.findViewById(R.id.card_list)
        deckId = arguments?.getInt("deck_id") ?: 1

        val addCardButton = layout.findViewById<FloatingActionButton>(R.id.add_card_button)
        val backButton = layout.findViewById<ImageButton>(R.id.back_button)
        val saveButton = layout.findViewById<ImageButton>(R.id.save_deck_button)
        val deleteButton = layout.findViewById<ImageButton>(R.id.delete_deck_button)

        addCardButton.setOnClickListener(addCardButtonOnClickListener)
        backButton.setOnClickListener(backButtonOnClickListener)
        saveButton.setOnClickListener(saveButtonOnClickListener)
        deleteButton.setOnClickListener(deleteButtonOnClickListener)

        setupDeckTitleEditText()
        setupList()

        return layout
    }

    /**
     * Обработчик кнопки добавлеия карты. Открывает диалоговое окно для создания карты.
     */
    private val addCardButtonOnClickListener = View.OnClickListener {
        CardDialogFragment().show(childFragmentManager, "Create Card")
    }

    /**
     * Обработчик кнопки возвращения в главное меню. Открывает диалоговое окно для подтверждения.
     */
    private val backButtonOnClickListener = View.OnClickListener {
        val titleView = layout.findViewById<EditText>(R.id.deck_title)
        if (titleView.text.toString() != initialDeckTitle) {
            ExitConfirmationDialogFragment().show(childFragmentManager, "Back button")
        } else {
            findNavController().popBackStack()
        }
    }

    /**
     * Обработчик кнопки сохранения колоды.
     * Сохраняет новое название колоды и возвращает в главное меню.
     */
    private val saveButtonOnClickListener = View.OnClickListener {
        val titleView = layout.findViewById<EditText>(R.id.deck_title)
        val updatedDeck = Deck(deckId, titleView.text.toString())
        MainScope().launch {
            repository.updateDeck(requireContext(), updatedDeck)
            findNavController().popBackStack()
        }
    }

    /**
     * Обработчик кнопки удалеия колоды. Открывает диалоговое окно для подтверждения.
     */
    private val deleteButtonOnClickListener = View.OnClickListener {
        DeleteConfirmationDialogFragment().show(childFragmentManager, "Delete deck")
    }

    /**
     * Устанавливает в поле с названием колоды название из БД.
     */
    private fun setupDeckTitleEditText() {
        MainScope().launch {
            val titleView = layout.findViewById<EditText>(R.id.deck_title)
            titleView.setText(repository.getDeck(requireContext(), deckId).title)
            initialDeckTitle = titleView.text.toString()
        }
    }

    /**
     * Иницализация списка карт из колоды.
     */
    private fun setupList() {
        val swipeController = SwipeController(object : SwipeControllerAction {
            override fun onButtonClicked(position: Int) {
                val card = cards[position]
                cards.removeAt(position)
                list.adapter?.notifyItemRemoved(position)
                list.adapter?.notifyItemRangeChanged(position, list.adapter!!.itemCount)
                MainScope().launch {
                    repository.deleteCard(requireContext(), card)
                }
            }
        })

        val itemTouchHelper = ItemTouchHelper(swipeController)
        itemTouchHelper.attachToRecyclerView(list)

        MainScope().launch {
            cards.addAll(repository.getCards(requireContext(), deckId))
            val adapter = CardListAdapter(cards)
            adapter.listener = this@DeckDetailedFragment
            list.adapter = adapter
            list.layoutManager = LinearLayoutManager(context)
            list.isNestedScrollingEnabled = false
        }

        list.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun onDraw(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
                swipeController.onDraw(c)
            }
        })
    }

    /**
     * Обработчик нажатия на карту. Создает диалоговое окно для редактирования карты.
     */
    override fun onCardClicked(position: Int) {
        CardDialogFragment(cards[position]).show(childFragmentManager, "Update card")
    }

    /**
     * Обработчик нажатия на положительную кнопку в диалоговом окне для создания карты.
     */
    override fun onCreateCardDialogPositiveClick(
        dialog: DialogFragment,
        front: String,
        back: String
    ) {
        // skip empty card
        if (front == "" || back == "") return

        MainScope().launch {
            val newCard = Card(0, front, back, deckId)
            repository.addCard(requireContext(), newCard)
            cards.clear()
            cards.addAll(repository.getCards(requireContext(), deckId))
            list.adapter?.notifyItemInserted(cards.size - 1)
        }
    }

    override fun onCreateCardDialogNegativeClick(dialog: DialogFragment) { }

    /**
     * Обработчик нажатия на положительную кнопку в диалоговом окне для редактированя карты.
     */
    override fun onUpdateCardDialogPositiveClick(dialog: DialogFragment, card: Card) {
        val position = cards.indexOf(card)
        cards[position] = card
        list.adapter?.notifyItemChanged(position)
        MainScope().launch {
            repository.updateCard(requireContext(), card)
        }
    }

    override fun onUpdateCardDialogNegativeClick(dialog: DialogFragment) { }

    /**
     * Обработчик нажатия на положительную кнопку в диалоговом окне для выхода в главное меню.
     */
    override fun onExitConfirmationDialogPositiveClick(dialog: DialogFragment) {
        findNavController().popBackStack()
    }

    override fun onExitConfirmationDialogNegativeClick(dialog: DialogFragment) { }

    /**
     * Обработчик нажатия на положительную кнопку в диалоговом окне для удаления колоды.
     */
    override fun onDeleteConfirmationDialogPositiveClick(dialog: DialogFragment) {
        MainScope().launch {
            val currentDeck = repository.getDeck(requireContext(), deckId)
            repository.deleteDeck(requireContext(), currentDeck)
            findNavController().popBackStack()
        }
    }

    override fun onDeleteConfirmationDialogNegativeClick(dialog: DialogFragment) { }

}

class CardDialogFragment(private val card: Card? = null) : DialogFragment() {
    private var create = false

    init {
        create = (card == null)
    }

    interface CardDialogListener {
        fun onCreateCardDialogPositiveClick(dialog: DialogFragment, front: String, back: String)
        fun onCreateCardDialogNegativeClick(dialog: DialogFragment)
        fun onUpdateCardDialogPositiveClick(dialog: DialogFragment, card: Card)
        fun onUpdateCardDialogNegativeClick(dialog: DialogFragment)
    }

    private lateinit var listener: CardDialogListener

    override fun onAttach(context: Context) {
        super.onAttach(context)

        try {
            listener = parentFragment as CardDialogListener
        } catch (e: ClassCastException) {
            throw ClassCastException(
                (context.toString() +
                        " must implement CreatePlaylistDialogListener")
            )
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)

            val view = requireActivity().layoutInflater.inflate(
                R.layout.dialog_create_card,
                null
            )

            if (!create) {
                view.findViewById<EditText>(R.id.card_front).setText(card!!.front)
                view.findViewById<EditText>(R.id.card_back).setText(card.back)
            }

            val title = if (create) {
                R.string.create_card_dialog_title
            } else {
                R.string.update_card_dialog_title
            }

            builder.setView(view)
                .setTitle(title)
                .setPositiveButton(android.R.string.ok,
                    DialogInterface.OnClickListener { _, _ ->
                        val front = view.findViewById<EditText>(R.id.card_front).text.toString()
                        val back = view.findViewById<EditText>(R.id.card_back).text.toString()
                        if (create) {
                            listener.onCreateCardDialogPositiveClick(this, front, back)
                        } else {
                            card!!.front = front
                            card.back = back
                            listener.onUpdateCardDialogPositiveClick(this, card)
                        }
                    })
                .setNegativeButton(R.string.cancel,
                    DialogInterface.OnClickListener { _, _ ->
                        if (create) {
                            listener.onCreateCardDialogNegativeClick(this)
                        } else {
                            listener.onUpdateCardDialogNegativeClick(this)
                        }
                    })

            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }
}

class ExitConfirmationDialogFragment : DialogFragment() {
    interface ExitConfirmationDialogListener {
        fun onExitConfirmationDialogPositiveClick(dialog: DialogFragment)
        fun onExitConfirmationDialogNegativeClick(dialog: DialogFragment)
    }

    private lateinit var listener: ExitConfirmationDialogListener

    override fun onAttach(context: Context) {
        super.onAttach(context)

        try {
            listener = parentFragment as ExitConfirmationDialogListener
        } catch (e: ClassCastException) {
            throw ClassCastException(
                (context.toString() +
                        " must implement CreatePlaylistDialogListener")
            )
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)

            builder.setTitle(R.string.exit_confirmation_dialog_title)
                .setPositiveButton(android.R.string.ok,
                    DialogInterface.OnClickListener { _, _ ->
                        listener.onExitConfirmationDialogPositiveClick(this)
                    })
                .setNegativeButton(R.string.cancel,
                    DialogInterface.OnClickListener { _, _ ->
                        listener.onExitConfirmationDialogNegativeClick(this)
                    })

            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }
}

class DeleteConfirmationDialogFragment : DialogFragment() {
    interface DeleteConfirmationDialogListener {
        fun onDeleteConfirmationDialogPositiveClick(dialog: DialogFragment)
        fun onDeleteConfirmationDialogNegativeClick(dialog: DialogFragment)
    }

    private lateinit var listener: DeleteConfirmationDialogListener

    override fun onAttach(context: Context) {
        super.onAttach(context)

        try {
            listener = parentFragment as DeleteConfirmationDialogListener
        } catch (e: ClassCastException) {
            throw ClassCastException(
                (context.toString() +
                        " must implement CreatePlaylistDialogListener")
            )
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)

            builder.setTitle(R.string.delete_confirmation_dialog_title)
                .setPositiveButton(android.R.string.ok,
                    DialogInterface.OnClickListener { _, _ ->
                        listener.onDeleteConfirmationDialogPositiveClick(this)
                    })
                .setNegativeButton(R.string.cancel,
                    DialogInterface.OnClickListener { _, _ ->
                        listener.onDeleteConfirmationDialogNegativeClick(this)
                    })

            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }
}