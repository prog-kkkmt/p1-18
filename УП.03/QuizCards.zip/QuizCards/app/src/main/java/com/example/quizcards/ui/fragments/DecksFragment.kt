package com.example.quizcards.ui.fragments

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.quizcards.R
import com.example.quizcards.data.Deck
import com.example.quizcards.data.DecksRepository
import com.example.quizcards.ui.adapters.DeckListAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

/**
 * Класс стартового экрана со списком колод.
 */
class DecksFragment : Fragment(), DeckListAdapter.Listener,
    CreateDeckDialogFragment.CreateDeckDialogListener {

    private val decks = ArrayList<Deck>()
    private val repository = DecksRepository.getInstance()
    private lateinit var layout: View
    private lateinit var list: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        layout = inflater.inflate(R.layout.fragment_decks, container, false)

        list = layout.findViewById(R.id.decks_list)

        // get decks from database in background
        MainScope().launch {
            decks.clear()
            decks.addAll(repository.getDecks(requireContext()))
            val adapter = DeckListAdapter(decks)
            adapter.listener = this@DecksFragment
            list.adapter = adapter
            list.layoutManager = LinearLayoutManager(context)
        }

        val fab = layout.findViewById<FloatingActionButton>(R.id.fab)
        fab.setOnClickListener(fabOnClickListener)

        return layout
    }

    /**
     * Обработчик кнопки создания колоды. Открывает диалоговое окно для ввода названия колоды.
     */
    private val fabOnClickListener = View.OnClickListener {
        CreateDeckDialogFragment().show(childFragmentManager, "Create Deck")
    }

    /**
     * Обработчик нажатия на кнопку редактирования колоды.
     * Открывает экран редактирования колоды.
     */
    override fun onEditButtonClicked(position: Int) {
        val bundle = Bundle()
        bundle.putInt("deck_id", decks[position].id)
        findNavController().navigate(R.id.action_decks_to_deckDetailed, bundle)
    }

    /**
     * Обработчик нажатия на кнопку запуска игры.
     * Открывает экран изучения колоды.
     */
    override fun onPlayButtonClicked(view: View, position: Int) {
        val deck = decks[position]
        MainScope().launch {
            if (repository.isDeckEmpty(requireContext(), deck)) {
                Snackbar.make(view, resources.getString(R.string.empty_deck), Snackbar.LENGTH_SHORT)
                    .setAction(resources.getString(R.string.edit_deck_snackbar)) {
                        val bundle = Bundle()
                        bundle.putInt("deck_id", decks[position].id)
                        findNavController().navigate(R.id.action_decks_to_deckDetailed, bundle)
                    }
                    .show()
            } else {
                val bundle = Bundle()
                bundle.putInt("deck_id", deck.id)
                findNavController().navigate(R.id.action_decks_to_game, bundle)
            }
        }
    }

    /**
     * Обработчик нажатия на положительную кнопку в диалоговом окне для создания колоды.
     */
    override fun onCreateDeckDialogPositiveClick(dialog: DialogFragment, deckName: String) {
        if (deckName == "") return

        MainScope().launch {
            val deck = Deck(0, deckName)
            repository.addDeck(requireContext(), deck)
            decks.clear()
            decks.addAll(repository.getDecks(requireContext()))
            list.adapter?.notifyDataSetChanged()
        }
    }

    override fun onCreateDeckDialogNegativeClick(dialog: DialogFragment) { }

}

class CreateDeckDialogFragment : DialogFragment() {

    interface CreateDeckDialogListener {
        fun onCreateDeckDialogPositiveClick(dialog: DialogFragment, deckName: String)
        fun onCreateDeckDialogNegativeClick(dialog: DialogFragment)
    }

    private lateinit var listener: CreateDeckDialogListener

    override fun onAttach(context: Context) {
        super.onAttach(context)

        try {
            listener = parentFragment as CreateDeckDialogListener
        } catch (e: ClassCastException) {
            throw ClassCastException((context.toString() +
                    " must implement CreatePlaylistDialogListener"))
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)

            val view = requireActivity().layoutInflater.inflate(
                R.layout.dialog_create_deck,
                null
            )

            builder.setView(view)
                .setTitle(R.string.create_deck_dialog_title)
                .setPositiveButton(android.R.string.ok,
                    DialogInterface.OnClickListener { _, _ ->
                        val name = view.findViewById<EditText>(R.id.deck_name).text.toString()
                        listener.onCreateDeckDialogPositiveClick(this, name)
                    })
                .setNegativeButton(R.string.cancel,
                    DialogInterface.OnClickListener { _, _ ->
                        listener.onCreateDeckDialogNegativeClick(this)
                    })

            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }

}