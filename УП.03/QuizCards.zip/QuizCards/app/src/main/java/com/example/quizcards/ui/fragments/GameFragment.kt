package com.example.quizcards.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.navigation.fragment.findNavController
import com.example.quizcards.R
import com.example.quizcards.data.Card
import com.example.quizcards.data.DecksRepository
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

/**
 * Класс экрана изучения колоды.
 */
class GameFragment : Fragment() {

    private val repository = DecksRepository.getInstance()
    private val cardsFromDeck = ArrayList<Card>()
    private val currentCards = ArrayList<Card>()
    private val repeatCards = ArrayList<Card>()
    private var isRotated = false
    private var isRotatingNow = false
    private var currentCardPosition = 1
    private var amountOfCards = 0
    private var deckId = 1
    private lateinit var layout: View
    private lateinit var cardView: CardView
    private lateinit var cardViewContent: TextView
    private lateinit var mainContent: ConstraintLayout
    private lateinit var loadingSpinner: ProgressBar
    private lateinit var resultLayout: ConstraintLayout
    private lateinit var currentCard: Card
    private lateinit var progressView: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        layout = inflater.inflate(R.layout.fragment_game, container, false)

        cardView = layout.findViewById(R.id.card_view)
        cardViewContent = layout.findViewById(R.id.card_content)
        mainContent = layout.findViewById(R.id.main_content)
        loadingSpinner = layout.findViewById(R.id.loading_spinner)
        resultLayout = layout.findViewById(R.id.result_layout)
        progressView = layout.findViewById(R.id.progress_view)

        deckId = arguments?.getInt("deck_id") ?: 1

        val backButton = layout.findViewById<ImageButton>(R.id.back_button)
        val repeatCardButton = layout.findViewById<ImageButton>(R.id.repeat_button)
        val rememberCardButton = layout.findViewById<ImageButton>(R.id.remember_button)
        val flipCardButton = layout.findViewById<Button>(R.id.flip_button)
        val continueGameButton = layout.findViewById<Button>(R.id.continue_button)
        val restartGameButton = layout.findViewById<Button>(R.id.restart_button)

        backButton.setOnClickListener(backButtonOnClickListener)
        repeatCardButton.setOnClickListener(repeatCardButtonOnClickListener)
        rememberCardButton.setOnClickListener(rememberCardButtonOnCLickListener)
        flipCardButton.setOnClickListener(flipCardButtonOnClickListener)
        continueGameButton.setOnClickListener(continueGameButtonOnClickListener)
        restartGameButton.setOnClickListener(restartGameButtonOnClickListener)

        loadGame()

        return layout
    }

    /**
     * Обработчик кнопки возвращения в главное меню.
     */
    private val backButtonOnClickListener = View.OnClickListener {
        findNavController().popBackStack()
    }

    /**
     * Обработчик кнопки повторения карты. Добавляет текущую карту в список карт для повторения.
     */
    private val repeatCardButtonOnClickListener = View.OnClickListener {
        repeatCards.add(currentCard)
        getNextCard()
    }

    /**
     * Обработчик кнопки запоминания карты. Открывает следующую карту.
     */
    private val rememberCardButtonOnCLickListener = View.OnClickListener {
        getNextCard()
    }

    /**
     * Обработчик кнопки перерорачивания карты. Создает анимация переворачивания карты.
     */
    private val flipCardButtonOnClickListener = View.OnClickListener {
        if (isRotatingNow) return@OnClickListener
        val scale = context?.resources?.displayMetrics?.density ?: 1F
        val distance = cardView.cameraDistance * (scale * (scale / 3))
        cardView.cameraDistance = distance
        val cardElevation = cardView.elevation
        cardView.elevation = 0F
        isRotatingNow = true
        cardView.animate().withLayer()
            .rotationY(90F)
            .setDuration(200L)
            .withEndAction {
                isRotated = !isRotated
                if (isRotated) {
                    cardViewContent.text = currentCard.back
                } else {
                    cardViewContent.text = currentCard.front
                }
                cardView.rotationY = -90F
                cardView.animate().withLayer()
                    .rotationY(0F)
                    .setDuration(200L)
                    .withEndAction {
                        isRotatingNow = false
                        cardView.elevation = cardElevation
                    }
                    .start()
            }
            .start()
    }

    /**
     * Обработчик кнопки продолжения игры. Запускает игру с картами из списка карт для повторения.
     */
    private val continueGameButtonOnClickListener = View.OnClickListener {
        currentCards.addAll(repeatCards)
        currentCard = currentCards.removeAt(0)
        repeatCards.clear()
        cardViewContent.text = currentCard.front
        isRotated = false
        currentCardPosition = 1
        updateProgressView()
        resultLayout.visibility = View.GONE
        mainContent.visibility = View.VISIBLE
    }

    /**
     * Обработчик кнопки перезапуска игры.
     */
    private val restartGameButtonOnClickListener = View.OnClickListener {
        currentCards.addAll(cardsFromDeck)
        repeatCards.clear()
        currentCard = currentCards.removeAt(0)
        cardViewContent.text = currentCard.front
        isRotated = false
        currentCardPosition = 1
        updateProgressView()
        resultLayout.visibility = View.GONE
        mainContent.visibility = View.VISIBLE
    }

    /**
     * Функция получения следующей карты. Обновляет графический интерфейс.
     */
    private fun getNextCard() {
        if (currentCards.isNotEmpty()) {
            currentCard = currentCards.removeAt(0)
            isRotated = false
            cardViewContent.text = currentCard.front
            currentCardPosition++
            updateProgressView()
        } else {
            finishGame()
        }
    }

    /**
     * Обновляет текстовую метку с прогрессом игры.
     */
    private fun updateProgressView() {
        if (currentCardPosition == 1) {
            amountOfCards = currentCards.size + 1
        }
        progressView.text = resources.getString(
            R.string.progress_view_placeholder, currentCardPosition, amountOfCards)
    }

    /**
     * Загружает игру.
     */
    private fun loadGame() {
        MainScope().launch {
            loadingSpinner.visibility = View.VISIBLE
            mainContent.visibility = View.GONE
            resultLayout.visibility = View.GONE

            cardsFromDeck.addAll(repository.getCards(requireContext(), deckId)) // O(2n)
            currentCards.addAll(cardsFromDeck) // O(n)
            currentCards.shuffle() // O(n)
            currentCard = currentCards.removeAt(0)
            cardViewContent.text = currentCard.front
            updateProgressView()

            loadingSpinner.visibility = View.GONE
            mainContent.visibility = View.VISIBLE
        }
    }

    /**
     * Функция, которая завершает игру и показывает результат
     */
    private fun finishGame() {
        // Поиск виджетов графического интерфейса
        val resultTextView = layout.findViewById<TextView>(R.id.result_text)
        val continueGameButton = layout.findViewById<Button>(R.id.continue_button)
        // Скрываем основную разметку
        mainContent.visibility = View.GONE
        // Если есть карты для повторения, показываем кнопку для продолжения игры
        if(repeatCards.isEmpty()) {
            resultTextView.text = resources.getString(R.string.complete_result)
            continueGameButton.visibility = View.GONE
        } else {
            resultTextView.text = resources.getString(R.string.remaining_result, repeatCards.size)
            continueGameButton.visibility = View.VISIBLE
        }
        // Открываем разметку результата
        resultLayout.visibility = View.VISIBLE
    }

}